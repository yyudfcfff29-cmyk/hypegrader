import React, {useState} from 'react';
import {Snowflake, Gift, Users, Clock3, ChevronRight, Star, ShieldCheck, Menu, Wallet, Ticket, Sparkles} from 'lucide-react';
import logo from './assets/hypegrader-logo.jpg';

type Kind='all'|'stars'|'channel';
const giveaways=[
 {id:1,kind:'stars',period:'ЕЖЕНЕДЕЛЬНЫЙ РОЗЫГРЫШ',name:'Heroic Helmet',sub:'Коллекционный подарок',price:'359',people:259,time:'5 дн. 02 ч.',art:'🪖',tag:'Главный приз',tone:'blue'},
 {id:2,kind:'channel',period:'РОЗЫГРЫШ ДЛЯ ПОДПИСЧИКОВ',name:'Eternal Rose',sub:'Коллекционный подарок',price:'Подписка',people:224,time:'19 ч. 46 мин.',art:'🌹',tag:'Бесплатное участие',tone:'violet'},
 {id:3,kind:'stars',period:'СПЕЦИАЛЬНЫЙ РОЗЫГРЫШ',name:'Diamond Ring',sub:'Коллекционный подарок',price:'99',people:118,time:'1 дн. 08 ч.',art:'💍',tag:'Популярное',tone:'cyan'}
];
export default function App(){
 const [filter,setFilter]=useState<Kind>('all');
 const [notice,setNotice]=useState('');
 const visible=giveaways.filter(g=>filter==='all'||g.kind===filter);
 const participate=(kind:string)=>setNotice(kind==='stars'?'Подключим оплату Telegram Stars на следующем этапе.':'Здесь появится проверка подписки на информационный канал.');
 return <div className="app-shell">
  <div className="snow s1"/><div className="snow s2"/><div className="snow s3"/>
  <header className="topbar">
   <div className="brand"><img src={logo}/><div><b>HypeGrader</b><span>WINTER SEASON</span></div></div>
   <button className="wallet" onClick={()=>setNotice('Подключение Telegram Wallet будет добавлено на следующем этапе.')}><Wallet size={17}/> <span>Баланс</span></button>
   <button className="menu" aria-label="Меню"><Menu/></button>
  </header>
  <main>
   <section className="hero">
    <div className="hero-copy"><div className="eyebrow"><Snowflake size={14}/> ЗИМНИЙ СЕЗОН 2026</div>
     <h1>Подарки,<br/><em>которые</em> хочется<br/>выиграть.</h1>
     <p>Участвуй в розыгрышах Telegram-подарков на HypeGrader.</p>
     <button className="primary" onClick={()=>document.getElementById('giveaways')?.scrollIntoView({behavior:'smooth'})}>Смотреть розыгрыши <ChevronRight size={18}/></button>
    </div>
    <div className="hero-orb"><div className="orb-ring"/><div className="orb-gift">🎁</div><span className="orb-spark">✦</span></div>
    <div className="hero-glow"/>
   </section>
   <section className="stats">
    <div><span className="stat-icon"><Gift/></span><b>03</b><small>Активных розыгрыша</small></div>
    <div><span className="stat-icon"><Users/></span><b>601</b><small>Участников</small></div>
    <div><span className="stat-icon"><ShieldCheck/></span><b>100%</b><small>Прозрачные итоги</small></div>
   </section>
   <section id="giveaways" className="section">
    <div className="section-heading"><div><div className="eyebrow"><Sparkles size={13}/> ВЫБИРАЙ СВОЙ ШАНС</div><h2>Активные розыгрыши</h2><p>Найди подарок, который достанется тебе.</p></div><span className="live"><i/> LIVE</span></div>
    <div className="filters">
     {(['all','stars','channel'] as Kind[]).map(k=><button key={k} className={filter===k?'selected':''} onClick={()=>setFilter(k)}>{k==='all'?'Все розыгрыши':k==='stars'?'⭐ За Stars':'❄ По подписке'}</button>)}
    </div>
    <div className="cards">{visible.map(g=><article className={`giveaway ${g.tone}`} key={g.id}>
      <div className="card-top"><span>{g.period}</span><span className="participants"><Users size={14}/>{g.people}</span></div>
      <div className="card-content"><div className="gift-art"><div className="gift-halo"/><span>{g.art}</span><small>✦</small></div>
       <div className="gift-info"><span className="tag">{g.tag}</span><h3>{g.name}</h3><p>{g.sub}</p>
        <div className="price">{g.price==='Подписка'?<span className="channel-price">Бесплатно</span>:<>{g.price}<Star size={25} fill="currentColor"/></>}</div>
        <div className="countdown"><Clock3 size={14}/><span>До завершения: <b>{g.time}</b></span></div>
       </div></div>
      <div className="card-bottom"><button onClick={()=>participate(g.kind)}>{g.kind==='stars'?'Участвовать за Stars':'Проверить подписку'} <ChevronRight size={17}/></button></div>
     </article>)}</div>
   </section>
   <section className="how"><div className="how-icon"><Ticket/></div><div><b>Всё просто</b><p>Выбери розыгрыш, выполни условия и следи за итогами. Победители будут определяться случайным образом.</p></div></section>
   <footer><div className="footer-brand"><img src={logo}/><b>HypeGrader</b></div><span>WINTER SEASON · 2026</span><p>Демонстрационная версия интерфейса</p></footer>
  </main>
  {notice&&<div className="toast" onClick={()=>setNotice('')}>{notice}<button>×</button></div>}
 </div>
}